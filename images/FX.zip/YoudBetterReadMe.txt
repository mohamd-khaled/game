Created by Martin Jelinek (jelinek.cz@gmail.com) | www.nyrthos.com

These are completely free to use in whatevere project you desire, be it a game, a hi-end visualisation of a camel poo, or.. well.. you�re probably smarter than me, so I�ll leave it up to you.

That being said, I�d definitely love to see whatever you manage to do with them, so please please please, let me know if that happens!

Cheers :) Martin