<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.3.1" name="24x24dungeon" tilewidth="24" tileheight="24" tilecount="800" columns="8">
 <image source="24x24_dungeon.png" trans="ff00ff" width="192" height="2400"/>
</tileset>
